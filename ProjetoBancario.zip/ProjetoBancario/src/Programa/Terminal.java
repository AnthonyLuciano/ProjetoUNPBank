/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Programa;
import java.util.ArrayList;
import java.util.Scanner;

public class Terminal {

    static Scanner input = new Scanner(System.in);
    static ArrayList<Conta> contasBancarias;
    
    public static void main(String[] args){
        contasBancarias = new ArrayList<Conta>();
        operacoes();
    
    
    }
    public static void operacoes(){
    System.out.println("================================================");
    System.out.println("==========Bem vindos a nossa agencia============");
    System.out.println("================================================");
    System.out.println("***Selecione uma operacao que deseja realizar***");
    System.out.println("================================================");
    System.out.println("|Opcao 1 - Depositar|");
    System.out.println("|Opcao 2 - transferir|");
    System.out.println("|Opcao 3 - sacar|");
    System.out.println("|Opcao 4 - sair|");
    
    int operacao = input.nextInt();
    
    switch(operacao){
        case 1:
            depositar();
            break;
        case 2:
            transferir();
            break;
        case 3:
            sacar();
            break;
        case 4:
            System.out.println("Tchau!");
            System.exit(0);
            break;
        default:
            System.out.println("opção invalida");
            operacoes();
            break;
    }
    }
    public static Conta encontrarConta(int numeroConta){
        Conta conta = null;
        if(contasBancarias.size()>0){
            for(Conta c: contasBancarias){
                if(c.getNumeroConta() == numeroConta);
                conta = c;
            }
        }
        return conta;
    }
    public static void depositar(){
        System.out.println("numero da conta: ");
        int numeroConta = input.nextInt();
        
        Conta conta = encontrarConta(numeroConta);
        
        if(conta != null){
            System.out.println("Qual valor deseja depositar?");
            Double ValorDeposito = input.nextDouble();
            conta.depositar(ValorDeposito);
            System.out.println("Valor depositado sucessivamente");
        }
        else{
            System.out.println("Conta não encontrada");
        }
        operacoes();
    }
    public static void transferir(){
        System.out.print("numero da conta do remetente: ");
        int numeroContaRemetente = input.nextInt();
        
        Conta contaRemetente = encontrarConta(numeroContaRemetente);
        
        if(contaRemetente != null){
            System.out.print("Numero da conta do destinatario: ");
            int numeroContaDestinatario = input.nextInt();
            
            Conta contaDestinatario = encontrarConta(numeroContaDestinatario);
            
            if(contaDestinatario !=null) {
                System.out.print("Valor da transferencia: ");
                Double valor = input.nextDouble();
                
                contaRemetente.transferir(contaDestinatario, valor);
            }else{System.out.print("A conta para deposito nao foi encontrada");}
           
        }else{System.out.println("Conta para Transferencia não encontrada");
        }
        operacoes();
    }
    
    public static void sacar(){
        System.out.println("numero da conta: ");
        int numeroConta = input.nextInt();
        
        Conta conta = encontrarConta(numeroConta);
        
        if(conta != null){
            System.out.println("Qual valor deseja sacar?");
            Double ValorSaque = input.nextDouble();
            conta.sacar(ValorSaque);
            System.out.println("Valor sacado sucessivamente");
        }
        else{
            System.out.println("Conta não encontrada");
        }
        operacoes();
    }
}