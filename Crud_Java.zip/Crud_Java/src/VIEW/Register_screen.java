package VIEW;

import DAO.CadastroDAO;
import DTO.CadastroDTO;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Vector;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

/**
 * @author tosca
 */
public class Register_screen extends javax.swing.JFrame {

    public Register_screen() {
        initComponents();
        listarValoresCliente();
        restaurarDadosComboBoxSexo();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        txtNomeCad = new javax.swing.JTextField();
        txtDataCad = new javax.swing.JFormattedTextField();
        txtCpfCad = new javax.swing.JFormattedTextField();
        cbxSexo = new javax.swing.JComboBox<>();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        txtEmailCad = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        BtnCadastrar = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();
        txtSenhaCad = new javax.swing.JPasswordField();
        jLabel7 = new javax.swing.JLabel();
        txtIdCad = new javax.swing.JTextField();
        btnAlterar = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        tabelaCliente = new javax.swing.JTable();
        btnGerarCampos = new javax.swing.JButton();
        BtnExcluir = new javax.swing.JButton();
        btnLimpar = new javax.swing.JButton();
        btnVoltarRegister = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Cadastro");
        setBackground(new java.awt.Color(255, 153, 102));

        jPanel1.setBackground(new java.awt.Color(51, 51, 51));
        jPanel1.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        txtNomeCad.setBackground(new java.awt.Color(15, 15, 15));
        txtNomeCad.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        txtNomeCad.setForeground(new java.awt.Color(255, 255, 255));
        txtNomeCad.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtNomeCadActionPerformed(evt);
            }
        });

        txtDataCad.setBackground(new java.awt.Color(15, 15, 15));
        txtDataCad.setForeground(new java.awt.Color(255, 255, 255));
        try {
            txtDataCad.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("##/##/####")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }
        txtDataCad.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N

        txtCpfCad.setBackground(new java.awt.Color(15, 15, 15));
        txtCpfCad.setForeground(new java.awt.Color(255, 255, 255));
        try {
            txtCpfCad.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("###.###.###-##")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }
        txtCpfCad.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N

        cbxSexo.setBackground(new java.awt.Color(15, 15, 15));
        cbxSexo.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        cbxSexo.setForeground(new java.awt.Color(255, 255, 255));
        cbxSexo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Selecione" }));
        cbxSexo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbxSexoActionPerformed(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Nome");

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Data de Nascimento");

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("CPF");

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Sexo");

        txtEmailCad.setBackground(new java.awt.Color(15, 15, 15));
        txtEmailCad.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        txtEmailCad.setForeground(new java.awt.Color(255, 255, 255));

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("E-mail");

        BtnCadastrar.setBackground(new java.awt.Color(51, 51, 255));
        BtnCadastrar.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        BtnCadastrar.setForeground(new java.awt.Color(255, 255, 255));
        BtnCadastrar.setText("Cadastrar");
        BtnCadastrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnCadastrarActionPerformed(evt);
            }
        });

        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("Senha ");

        txtSenhaCad.setBackground(new java.awt.Color(15, 15, 15));
        txtSenhaCad.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        txtSenhaCad.setForeground(new java.awt.Color(255, 255, 255));
        txtSenhaCad.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtSenhaCadActionPerformed(evt);
            }
        });

        jLabel7.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("ID");

        txtIdCad.setBackground(new java.awt.Color(0, 0, 0));
        txtIdCad.setForeground(new java.awt.Color(255, 255, 255));
        txtIdCad.setEnabled(false);
        txtIdCad.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtIdCadActionPerformed(evt);
            }
        });

        btnAlterar.setBackground(new java.awt.Color(51, 51, 255));
        btnAlterar.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnAlterar.setForeground(new java.awt.Color(255, 255, 255));
        btnAlterar.setText("Atualizar");
        btnAlterar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAlterarActionPerformed(evt);
            }
        });

        tabelaCliente.setBackground(new java.awt.Color(51, 51, 51));
        tabelaCliente.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        tabelaCliente.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        tabelaCliente.setForeground(new java.awt.Color(255, 255, 255));
        tabelaCliente.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "ID", "Nome", "Email", "CPF", "Senha", "Sexo"
            }
        ));
        tabelaCliente.setGridColor(new java.awt.Color(51, 51, 51));
        jScrollPane1.setViewportView(tabelaCliente);

        btnGerarCampos.setBackground(new java.awt.Color(51, 51, 255));
        btnGerarCampos.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnGerarCampos.setForeground(new java.awt.Color(255, 255, 255));
        btnGerarCampos.setText("Carregar dados");
        btnGerarCampos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGerarCamposActionPerformed(evt);
            }
        });

        BtnExcluir.setBackground(new java.awt.Color(204, 0, 0));
        BtnExcluir.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        BtnExcluir.setForeground(new java.awt.Color(255, 255, 255));
        BtnExcluir.setText("Excluir");
        BtnExcluir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnExcluirActionPerformed(evt);
            }
        });

        btnLimpar.setBackground(new java.awt.Color(51, 51, 255));
        btnLimpar.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnLimpar.setForeground(new java.awt.Color(255, 255, 255));
        btnLimpar.setText("Limpar");
        btnLimpar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLimparActionPerformed(evt);
            }
        });

        btnVoltarRegister.setBackground(new java.awt.Color(51, 51, 51));
        btnVoltarRegister.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGES/seta.png"))); // NOI18N
        btnVoltarRegister.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnVoltarRegister.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnVoltarRegisterActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(btnVoltarRegister, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel1)
                            .addComponent(jLabel3)
                            .addComponent(jLabel5)
                            .addComponent(jLabel6)
                            .addComponent(jLabel2)
                            .addComponent(cbxSexo, javax.swing.GroupLayout.PREFERRED_SIZE, 111, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtDataCad, javax.swing.GroupLayout.PREFERRED_SIZE, 111, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel4)
                            .addComponent(txtEmailCad, javax.swing.GroupLayout.DEFAULT_SIZE, 179, Short.MAX_VALUE)
                            .addComponent(txtCpfCad)
                            .addComponent(txtNomeCad)
                            .addComponent(txtIdCad)
                            .addComponent(txtSenhaCad))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 275, Short.MAX_VALUE)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(btnLimpar)
                                    .addComponent(btnGerarCampos))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(BtnExcluir, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(19, 19, 19)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addComponent(btnAlterar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(BtnCadastrar, javax.swing.GroupLayout.DEFAULT_SIZE, 103, Short.MAX_VALUE)))
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(14, 14, 14))))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(btnVoltarRegister)
                .addGap(43, 43, 43)
                .addComponent(jLabel7)
                .addGap(19, 19, 19)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(txtIdCad, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel1)
                        .addGap(18, 18, 18)
                        .addComponent(txtNomeCad, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel3)
                        .addGap(18, 18, 18)
                        .addComponent(txtCpfCad, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel5)
                        .addGap(18, 18, 18)
                        .addComponent(txtEmailCad, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel6)
                        .addGap(18, 18, 18)
                        .addComponent(txtSenhaCad, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(cbxSexo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 256, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(btnGerarCampos, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(BtnCadastrar)
                                        .addComponent(BtnExcluir, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                                .addGap(12, 12, 12)
                                .addComponent(btnAlterar))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(39, 39, 39)
                                .addComponent(btnLimpar)))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel2)
                .addGap(18, 18, 18)
                .addComponent(txtDataCad, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(35, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void txtNomeCadActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtNomeCadActionPerformed

    }//GEN-LAST:event_txtNomeCadActionPerformed

    private void BtnCadastrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnCadastrarActionPerformed
        cadastrarCliente();
        listarValoresCliente();
        limparCampos();
    }//GEN-LAST:event_BtnCadastrarActionPerformed

    private void cbxSexoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbxSexoActionPerformed

    }//GEN-LAST:event_cbxSexoActionPerformed

    private void txtSenhaCadActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtSenhaCadActionPerformed

    }//GEN-LAST:event_txtSenhaCadActionPerformed

    private void txtIdCadActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtIdCadActionPerformed

    }//GEN-LAST:event_txtIdCadActionPerformed

    private void btnAlterarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAlterarActionPerformed
        alterarCliente();
        listarValoresCliente();
        limparCampos();
    }//GEN-LAST:event_btnAlterarActionPerformed

    private void btnGerarCamposActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGerarCamposActionPerformed
        CarregarCampos();
    }//GEN-LAST:event_btnGerarCamposActionPerformed

    private void BtnExcluirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnExcluirActionPerformed
        ExcluirCliente();
        listarValoresCliente();
    }//GEN-LAST:event_BtnExcluirActionPerformed

    private void btnLimparActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLimparActionPerformed
        limparCampos();
    }//GEN-LAST:event_btnLimparActionPerformed

    private void btnVoltarRegisterActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVoltarRegisterActionPerformed
        Main_screen objmain_screen = new Main_screen();
        objmain_screen.setVisible(true);
        dispose();
    }//GEN-LAST:event_btnVoltarRegisterActionPerformed

    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Register_screen().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BtnCadastrar;
    private javax.swing.JButton BtnExcluir;
    private javax.swing.JButton btnAlterar;
    private javax.swing.JButton btnGerarCampos;
    private javax.swing.JButton btnLimpar;
    private javax.swing.JButton btnVoltarRegister;
    private javax.swing.JComboBox<String> cbxSexo;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tabelaCliente;
    private javax.swing.JFormattedTextField txtCpfCad;
    private javax.swing.JFormattedTextField txtDataCad;
    private javax.swing.JTextField txtEmailCad;
    private javax.swing.JTextField txtIdCad;
    private javax.swing.JTextField txtNomeCad;
    private javax.swing.JPasswordField txtSenhaCad;
    // End of variables declaration//GEN-END:variables

    //Metódo para verificar se o cpf do cliente é válido :
    public static boolean ÉCpfValido(String txtCpfCad) {
        txtCpfCad = txtCpfCad.replace(".", "").replace("-", "");

        if ((txtCpfCad == null) || (txtCpfCad.length() != TamanhoCPF)) {
            return false;
        }

        int[] numeros = new int[TamanhoCPF];
        for (int i = 0; i < TamanhoCPF; i++) {
            numeros[i] = Character.getNumericValue(txtCpfCad.charAt(i));
        }

        int resto = 0;
        for (int i = 0; i < 9; i++) {
            resto += numeros[i] * (10 - i);
        }
        int verificador = resto % TamanhoCPF;
        if ((verificador == 0) || (verificador == 1)) {
            verificador = 0;
        } else {
            verificador = TamanhoCPF - verificador;
        }
        if (verificador != numeros[9]) {
            return false;
        }

        resto = 0;
        for (int i = 0; i < 10; i++) {
            resto += numeros[i] * (TamanhoCPF - i);
        }
        verificador = resto % TamanhoCPF;
        if ((verificador == 0) || (verificador == 1)) {
            verificador = 0;
        } else {
            verificador = TamanhoCPF - verificador;
        }
        if (verificador != numeros[10]) {
            return false;
        }

        return true;
    }

    private static final int TamanhoCPF = 11;
   
    //Metódo para cadastrar as informações do cliente :
    private void cadastrarCliente() {
        String nome, email, senha, cpf, idade, sexo;

        nome = txtNomeCad.getText();
        email = txtEmailCad.getText();
        senha = txtSenhaCad.getText();
        sexo = cbxSexo.getSelectedItem().toString();
        idade = txtDataCad.getText();

        cpf = txtCpfCad.getText();
        if (ÉCpfValido(cpf)) {

            System.out.println("[O CPF é valido.]");

            CadastroDTO objcadastrodto = new CadastroDTO();
            objcadastrodto.setNome_cliente(nome);
            objcadastrodto.setEmail_cliente(email);
            objcadastrodto.setCpf_cliente(cpf);
            objcadastrodto.setSenha_cliente(senha);
            objcadastrodto.setSexo_cliente(sexo);

            CadastroDAO objcadastrodao = new CadastroDAO();
            objcadastrodao.cadastrarCliente(objcadastrodto);
            JOptionPane.showMessageDialog(null, "Cadastro realizado com sucesso: \n" + txtCpfCad.getText());

        } else {
            JOptionPane.showMessageDialog(null, "[O CPF é invalido, tente novamente]\n");
        }

    }

    //Metódo para pesquisar as informações dos clientes na tabela:
    private void listarValoresCliente() {
        try {
            CadastroDAO objcadastrodao = new CadastroDAO();

            DefaultTableModel model = (DefaultTableModel) tabelaCliente.getModel();
            model.setNumRows(0);

            ArrayList<CadastroDTO> lista = objcadastrodao.PesquisarCliente();

            for (int num = 0; num < lista.size(); num++) {
                model.addRow(new Object[]{
                    lista.get(num).getId_cliente(),
                    lista.get(num).getNome_cliente(),
                    lista.get(num).getEmail_cliente(),
                    lista.get(num).getCpf_cliente(),
                    lista.get(num).getSenha_cliente(),
                    lista.get(num).getSexo_cliente()
                });
            }
        } catch (Exception Erro) {
            JOptionPane.showMessageDialog(null, "Listar Valores VIEW: " + Erro);
        }
    }

    //Metódo para limpar os campos de texto
    private void limparCampos() {
        txtIdCad.setText("");
        txtNomeCad.setText("");
        txtCpfCad.setText("");
        txtEmailCad.setText("");
        txtSenhaCad.setText("");
        txtNomeCad.requestFocus();

    }

    //Metódo para atualizar as informações dos clientes :
    private void alterarCliente() {
        int id_cliente;
        String nome_cliente, email_cliente, cpf_cliente, senha_cliente;

        id_cliente = Integer.parseInt(txtIdCad.getText());
        nome_cliente = txtNomeCad.getText();
        cpf_cliente = txtCpfCad.getText();
        email_cliente = txtEmailCad.getText();
        senha_cliente = txtSenhaCad.getText();

        CadastroDTO objcadastrodto = new CadastroDTO();
        objcadastrodto.setId_cliente(id_cliente);
        objcadastrodto.setNome_cliente(nome_cliente);
        objcadastrodto.setCpf_cliente(cpf_cliente);
        objcadastrodto.setEmail_cliente(email_cliente);
        objcadastrodto.setSenha_cliente(senha_cliente);

        CadastroDAO objcadastrodao = new CadastroDAO();
        objcadastrodao.alterarCliente(objcadastrodto);

    }

    //Metódo para Carregar as informações do cliente nos campos de texto :
    private void CarregarCampos() {
        int setar = tabelaCliente.getSelectedRow();

        txtIdCad.setText(tabelaCliente.getModel().getValueAt(setar, 0).toString());
        txtNomeCad.setText(tabelaCliente.getModel().getValueAt(setar, 1).toString());
        txtEmailCad.setText(tabelaCliente.getModel().getValueAt(setar, 2).toString());
        txtCpfCad.setText(tabelaCliente.getModel().getValueAt(setar, 3).toString());
        txtSenhaCad.setText(tabelaCliente.getModel().getValueAt(setar, 4).toString());
    }

    //Metódo para excluir o cliente da database 
    private void ExcluirCliente() {
        int id_cliente;
        id_cliente = Integer.parseInt(txtIdCad.getText());

        CadastroDTO objcadastrodto = new CadastroDTO();
        objcadastrodto.setId_cliente(id_cliente);

        CadastroDAO objcadastrodao = new CadastroDAO();
        objcadastrodao.excluirCliente(objcadastrodto);

    }

    //Metódo para pegar os dados do sql e jogar na combobox
    Vector<Integer> id_sexo = new Vector<Integer>();

    private void restaurarDadosComboBoxSexo() {

        try {

            CadastroDAO objcadastrodao = new CadastroDAO();
            ResultSet rs = objcadastrodao.listarSexo();

            while (rs.next()) {

                id_sexo.addElement(rs.getInt(1));
                cbxSexo.addItem(rs.getString(2));

            }
        } catch (SQLException Erro) {
            JOptionPane.showMessageDialog(null, "ComboBoxSexo VIEW" + Erro.getMessage());

            return;

        }

    }
}
