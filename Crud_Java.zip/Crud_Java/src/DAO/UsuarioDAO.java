
package DAO;

/**
 *
 * @author tosca
 */
import DTO.DTOUsuario;

import java.sql.ResultSet;
import java.sql.Connection;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import java.sql.PreparedStatement;

public class UsuarioDAO {
    
    Connection conn;
    
    public ResultSet autenticacaoUsuario(DTOUsuario objusuariodto){
        conn = new ConexaoDAO().unpbank();
        
        try {
            
            String sql = "select * from funcionarios where cpf_funcionario = ? and senha_funcionario = ? ";
            
            PreparedStatement pstm = conn.prepareStatement(sql);
            
            pstm.setString(1, objusuariodto.getcpf_funcionario());
            pstm.setString(2, objusuariodto.getSenha_funcionario());
            
            ResultSet rs = pstm.executeQuery();
            return rs;
                    
        } catch(SQLException Erro){
            JOptionPane.showMessageDialog(null, "UsuarioDAO" +Erro);
            return null;     
        }
        
        
        
    }
    
}
