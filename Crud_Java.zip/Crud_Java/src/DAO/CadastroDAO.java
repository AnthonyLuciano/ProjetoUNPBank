package DAO;

import java.sql.PreparedStatement;
import DTO.CadastroDTO;
import java.sql.Connection;
import javax.swing.JOptionPane;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 * @author tosca
 */
public class CadastroDAO {

    Connection conn;
    PreparedStatement pstm;
    ResultSet rs;
    ArrayList<CadastroDTO> lista = new ArrayList<>();

    public void cadastrarCliente(CadastroDTO objcadastrodto) {
        String sql = "insert into clientes(id_cliente, nome_cliente, email_cliente, senha_cliente, cpf_cliente, sexo_cliente, idade_cliente) values (?,?,?,?,?,?,?)";

        conn = new ConexaoDAO().unpbank();

        try {
            pstm = conn.prepareStatement(sql);

            pstm.setInt(1, objcadastrodto.getId_cliente());
            pstm.setString(2, objcadastrodto.getNome_cliente());
            pstm.setString(3, objcadastrodto.getEmail_cliente());
            pstm.setString(4, objcadastrodto.getSenha_cliente());
            pstm.setString(5, objcadastrodto.getCpf_cliente());
            pstm.setString(6, objcadastrodto.getSexo_cliente());
            pstm.setString(7, objcadastrodto.getIdade_cliente());
            
            pstm.execute();
            pstm.close();
        } catch (Exception Erro) {
            JOptionPane.showMessageDialog(null, "CadastroDAO Cadastrar: " + Erro);

        }

    }

    public ArrayList<CadastroDTO> PesquisarCliente() {
        String sql = "select * from clientes";

        conn = new ConexaoDAO().unpbank();

        try {
            pstm = conn.prepareStatement(sql);
            rs = pstm.executeQuery();

            while (rs.next()) {

                CadastroDTO objcadastrodto = new CadastroDTO();

                objcadastrodto.setId_cliente(rs.getInt("id_cliente"));
                objcadastrodto.setNome_cliente(rs.getString("nome_cliente"));
                objcadastrodto.setEmail_cliente(rs.getString("email_cliente"));
                objcadastrodto.setCpf_cliente(rs.getString("cpf_cliente"));
                objcadastrodto.setSenha_cliente(rs.getString("senha_cliente"));
                objcadastrodto.setSexo_cliente(rs.getString("sexo_cliente"));
                objcadastrodto.setIdade_cliente(rs.getString("idade_cliente"));

                lista.add(objcadastrodto);

            }

        } catch (SQLException Erro) {
            JOptionPane.showMessageDialog(null, "CadastroDAO Pesquisar: " + Erro);
        }

        return lista;
    }

    public void alterarCliente(CadastroDTO objcadastrodto) {
        String sql = "update clientes set nome_cliente = ?, email_cliente = ?, cpf_cliente = ?, senha_cliente = ? where id_cliente = ?";

        conn = new ConexaoDAO().unpbank();

        try {
            pstm = conn.prepareStatement(sql);

            pstm.setString(1, objcadastrodto.getNome_cliente());
            pstm.setString(2, objcadastrodto.getEmail_cliente());
            pstm.setString(3, objcadastrodto.getCpf_cliente());
            pstm.setString(4, objcadastrodto.getSenha_cliente());
            pstm.setInt(5, objcadastrodto.getId_cliente());

            pstm.execute();
            pstm.close();

        } catch (SQLException Erro) {

            JOptionPane.showMessageDialog(null, "CadastroDAO Alterar: " + Erro);

        }
    }

    public void excluirCliente(CadastroDTO objcadastrodto) {
        String sql = "delete from clientes where id_cliente = ?";

        conn = new ConexaoDAO().unpbank();

        try {
            pstm = conn.prepareStatement(sql);

            pstm.setInt(1, objcadastrodto.getId_cliente());

            pstm.execute();
            pstm.close();

        } catch (Exception Erro) {

            JOptionPane.showMessageDialog(null, "CadastroDAO Excluir: " + Erro);

        }

    }

    public ResultSet listarSexo() {
        
        conn = new ConexaoDAO().unpbank();
        String sql = "SELECT * FROM sexo ORDER BY descricao_sexo;";

        try {

            pstm = conn.prepareStatement(sql);
            return pstm.executeQuery();

        } catch (SQLException Erro) {
            
            JOptionPane.showMessageDialog(null, "ListarSexo CadastroDAO" + Erro.getMessage());
            
            return null;
        }

    }
}
