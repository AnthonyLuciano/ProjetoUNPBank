
package DTO;

/**
 *
 * @author tosca
 */
public class DTOUsuario {
    
    private int id_funcionario;
    private String cpf_funcionario, senha_funcionario;

    public int getId_funcionario() {
        return id_funcionario;
    }

    public void setId_funcionario(int id_funcionario) {
        this.id_funcionario = id_funcionario;
    }

    public String getcpf_funcionario() {
        return cpf_funcionario;
    }

    public void setcpf_funcionario(String cpf_funcionario) {
        this.cpf_funcionario = cpf_funcionario;
    }

    public String getSenha_funcionario() {
        return senha_funcionario;
    }

    public void setSenha_funcionario(String senha_funcionario) {
        this.senha_funcionario = senha_funcionario;
    }
    
  
}
