package DTO;

/**
 * @author tosca
 */
public class SexoDTO {

    private int id_cargo;
    private String descricao_sexo;

    public int getId_cargo() {
        return id_cargo;
    }

    public void setId_cargo(int id_cargo) {
        this.id_cargo = id_cargo;
    }

    public String getDescricao_sexo() {
        return descricao_sexo;
    }

    public void setDescricao_sexo(String descricao_sexo) {
        this.descricao_sexo = descricao_sexo;
    }

}
