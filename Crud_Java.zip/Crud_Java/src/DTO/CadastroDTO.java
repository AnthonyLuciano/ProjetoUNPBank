package DTO;

import java.util.Random;
/**
 * @author tosca
 */
public class CadastroDTO {
    
    Random rand = new Random();
    private String nome_cliente, email_cliente, senha_cliente, cpf_cliente, sexo_cliente, idade_cliente;
    private int id_cliente = rand.nextInt(1000);
    
    public String getNome_cliente() {
        return nome_cliente;
    }

    public void setNome_cliente(String nome_cliente) {
        this.nome_cliente = nome_cliente;
    }

    public String getEmail_cliente() {
        return email_cliente;
    }

    public void setEmail_cliente(String email_cliente) {
        this.email_cliente = email_cliente;
    }

    public String getCpf_cliente() {
        return cpf_cliente;
    }

    public void setCpf_cliente(String cpf_cliente) {
        this.cpf_cliente = cpf_cliente;
    }

    public String getSenha_cliente() {
        return senha_cliente;
    }

    public void setSenha_cliente(String senha_cliente) {
        this.senha_cliente = senha_cliente;
    }

    public int getId_cliente() {
        return id_cliente;
    }

    public void setId_cliente(int id_cliente) {
        this.id_cliente = id_cliente;
    }   

    public String getSexo_cliente() {
        return sexo_cliente;
    }

    public void setSexo_cliente(String sexo_cliente) {
        this.sexo_cliente = sexo_cliente;
    }

    public String getIdade_cliente() {
        return idade_cliente;
    }

    public void setIdade_cliente(String idade_cliente) {
        this.idade_cliente = idade_cliente;
    }
    
    }
    

